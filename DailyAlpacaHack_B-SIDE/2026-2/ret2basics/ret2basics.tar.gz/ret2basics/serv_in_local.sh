# If you use Ubuntu 22.04 or higher version, please disable kernel.apparmor_restrict_unprivileged_userns

echo "disabling kernel.apparmor_restrict_unprivileged_userns..."
sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0
echo "building docker image..."
sudo docker compose build
echo "now start pwn at: nc localhost 33337"
sudo docker compose up
