EXAMPLE_FILE = "/usr/share/dict/words"
FLAG_EATER = open("/dev/null", "w")
DUMMY_EATER = open("/dev/null", "w")

while True:
    file = input(f"File (Default: {EXAMPLE_FILE}, Flag: flag.txt): ")
    pattern = input("Pattern: ")
    content = open(file or EXAMPLE_FILE).read(0x10000)
    for line in content.splitlines():
        if pattern in line:
            print(line, file=FLAG_EATER if "Alpaca" in line else None)
        else:
            print(line, file=DUMMY_EATER) # dummy write to avoid timing attacks :)
