from flask import Flask, Response, render_template, request
import string
import sqlite3

import initdb


app = Flask(__name__)

def get_sushi(sql):
    try:
        conn = sqlite3.connect('sushi.db')
        cursor = conn.cursor()
        sql = f"SELECT * FROM sushi WHERE {sql};" if len(sql) > 0 else f"SELECT * FROM sushi;"
        cursor.execute(sql)
        sushi_list = cursor.fetchall()
        conn.close()
        return sushi_list[:3]
    except:
        return []

@app.route('/')
def index():
    sql = request.args.get("sql", "price > 100")
    
    if "id" in sql:
        return render_template('index.html', sushi_list=[], error="「id」は禁止されています!")
    sushi_list = get_sushi(sql)
    return render_template('index.html', sushi_list=sushi_list)

initdb.init_db()

if __name__ == "__main__":
    app.run(port=1337, debug=True)