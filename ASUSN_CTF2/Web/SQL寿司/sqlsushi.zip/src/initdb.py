import sqlite3
import os
import random

FLAG = os.environ.get("FLAG", "flag{fake_flag}")

data = [
    ('マグロ', 300),
    ('サーモン', 250),
    ('エビ', 200),
    ('ホタテ', 350),
    ('ウニ', 500),
    ('イクラ', 450),
    ('アジ', 220),
    ('イカ', 180),
    ('タコ', 190),
    ('ハマチ', 280),
    ('カンパチ', 320),
    ('ブリ', 340),
    ('トロ', 600),
    ('中トロ', 550),
    ('ネギトロ', 400),
    ('サバ', 210),
    ('コハダ', 240),
    ('タイ', 300),
    ('ヒラメ', 320),
    ('カツオ', 260),
    ('シメサバ', 230),
    ('アワビ', 600),
    ('シラウオ', 270),
    ('サーモンマリネ', 260),
    ('ツブ貝', 370),
    ('カニ', 450),
    ('ホッキ貝', 300),
    ('カキ', 400),
    ('ホタルイカ', 320),
    ('シラス', 230),
    ('カジキ', 290),
    ('マゴチ', 310),
    ('アカガイ', 380),
    ('シャコ', 240),
    ('ガリ', 50),
    ('甘エビ', 270),
    ('ハモ', 280),
    ('ヤリイカ', 260),
    ('スズキ', 310),
    ('フグ', 500),
    ('キンメダイ', 480),
    ('メバル', 310),
    ('タラバガニ', 600),
    ('ズワイガニ', 550),
    ('アオリイカ', 290),
    ('マツブ貝', 360),
    ('サワラ', 290),
    ('カワハギ', 320),
    ('ハタハタ', 260),
    (FLAG, random.randint(15,60) * 10)
]


def init_db():
    
    if os.path.exists("sushi.db"):
        os.remove("sushi.db")
    
    conn = sqlite3.connect('sushi.db')
    cursor = conn.cursor()
    cursor.execute('''
CREATE TABLE IF NOT EXISTS sushi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price INTEGER NOT NULL
)
''')
    cursor.executemany('INSERT INTO sushi (name, price) VALUES (?, ?)', data)
    conn.commit()
    conn.close()