#!/bin/bash

while true; do
  gunicorn app:app --bind 0.0.0.0:1337
  sleep 1
done