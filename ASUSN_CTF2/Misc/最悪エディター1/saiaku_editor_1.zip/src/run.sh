#!/bin/sh
emacs /hello.txt
cat /flag.txt